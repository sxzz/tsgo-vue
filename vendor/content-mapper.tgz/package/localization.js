"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUnusedExpectErrorMessage = getUnusedExpectErrorMessage;
const fs = __importStar(require("node:fs"));
const path = __importStar(require("node:path"));
const unusedExpectErrorKey = 'Unused_ts_expect_error_directive_2578';
const defaultUnusedExpectErrorMessage = "Unused '@ts-expect-error' directive.";
const supportedLocaleDirectories = [
    'cs',
    'de',
    'es',
    'fr',
    'it',
    'ja',
    'ko',
    'pl',
    'pt-br',
    'ru',
    'tr',
    'zh-cn',
    'zh-tw',
];
function getUnusedExpectErrorMessage(locale, typescriptPath) {
    if (!locale) {
        return defaultUnusedExpectErrorMessage;
    }
    const libDirectory = typescriptPath
        ? path.dirname(typescriptPath)
        : path.dirname(require.resolve('typescript'));
    const candidate = resolveLocaleDirectory(locale);
    if (candidate) {
        const fileName = path.join(libDirectory, candidate, 'diagnosticMessages.generated.json');
        if (fs.existsSync(fileName)) {
            const messages = JSON.parse(fs.readFileSync(fileName, 'utf8'));
            const message = messages[unusedExpectErrorKey];
            if (typeof message === 'string') {
                return message;
            }
        }
    }
    return defaultUnusedExpectErrorMessage;
}
function resolveLocaleDirectory(locale) {
    const [canonical] = Intl.getCanonicalLocales(locale.replace(/_/g, '-'));
    if (!canonical) {
        return;
    }
    const requested = new Intl.Locale(canonical).maximize();
    let languageMatch;
    for (const candidate of supportedLocaleDirectories) {
        const supported = new Intl.Locale(candidate).maximize();
        if (supported.language !== requested.language) {
            continue;
        }
        languageMatch ??= candidate;
        if (supported.script === requested.script) {
            return candidate;
        }
    }
    return languageMatch;
}
