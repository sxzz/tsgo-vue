"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformVue = exports.closeProject = exports.openProject = exports.vueContentMapper = void 0;
const mapper_1 = require("./mapper");
const optionDiagnostics_1 = require("./optionDiagnostics");
/** The `.vue` content mapper: Vue single-file components, registered for `.vue` by the host. */
exports.vueContentMapper = (0, mapper_1.createContentMapper)({
    name: 'Vue content mapper',
    toOptionDiagnostics: optionDiagnostics_1.toOptionDiagnostics,
});
exports.openProject = exports.vueContentMapper.openProject;
exports.closeProject = exports.vueContentMapper.closeProject;
exports.transformVue = exports.vueContentMapper.transform;
