"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SpanMapFeature = exports.SpanMapKind = exports.DiagnosticDirectivePolicy = void 0;
var DiagnosticDirectivePolicy;
(function (DiagnosticDirectivePolicy) {
    DiagnosticDirectivePolicy[DiagnosticDirectivePolicy["Ignore"] = 0] = "Ignore";
    DiagnosticDirectivePolicy[DiagnosticDirectivePolicy["Expect"] = 1] = "Expect";
})(DiagnosticDirectivePolicy || (exports.DiagnosticDirectivePolicy = DiagnosticDirectivePolicy = {}));
var SpanMapKind;
(function (SpanMapKind) {
    SpanMapKind[SpanMapKind["Verbatim"] = 0] = "Verbatim";
    SpanMapKind[SpanMapKind["Atom"] = 1] = "Atom";
    SpanMapKind[SpanMapKind["Alias"] = 2] = "Alias";
})(SpanMapKind || (exports.SpanMapKind = SpanMapKind = {}));
var SpanMapFeature;
(function (SpanMapFeature) {
    SpanMapFeature[SpanMapFeature["Hover"] = 1] = "Hover";
    SpanMapFeature[SpanMapFeature["SignatureHelp"] = 2] = "SignatureHelp";
    SpanMapFeature[SpanMapFeature["Completion"] = 4] = "Completion";
    SpanMapFeature[SpanMapFeature["Definition"] = 8] = "Definition";
    SpanMapFeature[SpanMapFeature["TypeDefinition"] = 16] = "TypeDefinition";
    SpanMapFeature[SpanMapFeature["Implementation"] = 32] = "Implementation";
    SpanMapFeature[SpanMapFeature["References"] = 64] = "References";
    SpanMapFeature[SpanMapFeature["DocumentHighlights"] = 128] = "DocumentHighlights";
    SpanMapFeature[SpanMapFeature["Rename"] = 256] = "Rename";
    SpanMapFeature[SpanMapFeature["CallHierarchy"] = 512] = "CallHierarchy";
    SpanMapFeature[SpanMapFeature["CodeActions"] = 1024] = "CodeActions";
    SpanMapFeature[SpanMapFeature["Formatting"] = 2048] = "Formatting";
    SpanMapFeature[SpanMapFeature["InlayHints"] = 4096] = "InlayHints";
    SpanMapFeature[SpanMapFeature["SemanticTokens"] = 8192] = "SemanticTokens";
    SpanMapFeature[SpanMapFeature["FoldingRanges"] = 16384] = "FoldingRanges";
    SpanMapFeature[SpanMapFeature["SelectionRanges"] = 32768] = "SelectionRanges";
    SpanMapFeature[SpanMapFeature["LinkedEditing"] = 65536] = "LinkedEditing";
    SpanMapFeature[SpanMapFeature["AutoInsert"] = 131072] = "AutoInsert";
    SpanMapFeature[SpanMapFeature["DocumentSymbols"] = 262144] = "DocumentSymbols";
    SpanMapFeature[SpanMapFeature["CodeLens"] = 524288] = "CodeLens";
})(SpanMapFeature || (exports.SpanMapFeature = SpanMapFeature = {}));
