"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _TransformPool_instances, _TransformPool_mapper, _TransformPool_nextRequestId, _TransformPool_projects, _TransformPool_workers, _TransformPool_workerPath, _TransformPool_createWorker, _TransformPool_getParallelWorker, _TransformPool_ensureProject, _TransformPool_request, _TransformPool_failWorker;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransformPool = void 0;
exports.readWorkerCount = readWorkerCount;
const node_os_1 = require("node:os");
const path = __importStar(require("node:path"));
const node_worker_threads_1 = require("node:worker_threads");
const defaultWorkerCount = Math.min(4, (0, node_os_1.availableParallelism)());
const filesBeforeParallelism = 32;
class TransformPool {
    constructor(mapper, workerCount = readWorkerCount(), workerPath = path.resolve(__dirname, 'worker.js')) {
        _TransformPool_instances.add(this);
        _TransformPool_mapper.set(this, void 0);
        _TransformPool_nextRequestId.set(this, 0);
        _TransformPool_projects.set(this, new Map());
        _TransformPool_workers.set(this, void 0);
        _TransformPool_workerPath.set(this, void 0);
        this.workerCount = workerCount;
        __classPrivateFieldSet(this, _TransformPool_mapper, mapper, "f");
        __classPrivateFieldSet(this, _TransformPool_workerPath, workerPath, "f");
        __classPrivateFieldSet(this, _TransformPool_workers, workerCount === 1
            ? []
            : [__classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_createWorker).call(this)], "f");
    }
    async openProject(params) {
        if (this.workerCount === 1) {
            return __classPrivateFieldGet(this, _TransformPool_mapper, "f").openProject(params);
        }
        if (__classPrivateFieldGet(this, _TransformPool_projects, "f").has(params.projectHandle)) {
            throw new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} project is already open: ${params.projectHandle}`);
        }
        const primaryWorker = __classPrivateFieldGet(this, _TransformPool_workers, "f")[0];
        if (!primaryWorker) {
            throw new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} has no available worker`);
        }
        const project = {
            params,
            primaryWorker,
            fileWorkers: new Map(),
        };
        __classPrivateFieldGet(this, _TransformPool_projects, "f").set(params.projectHandle, project);
        try {
            const result = await __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_ensureProject).call(this, primaryWorker, project);
            project.configIdentity = result.configIdentity;
            return result;
        }
        catch (error) {
            __classPrivateFieldGet(this, _TransformPool_projects, "f").delete(params.projectHandle);
            throw error;
        }
    }
    async closeProject(params) {
        if (this.workerCount === 1) {
            __classPrivateFieldGet(this, _TransformPool_mapper, "f").closeProject(params.projectHandle);
            return;
        }
        const project = __classPrivateFieldGet(this, _TransformPool_projects, "f").get(params.projectHandle);
        __classPrivateFieldGet(this, _TransformPool_projects, "f").delete(params.projectHandle);
        if (!project) {
            return;
        }
        await Promise.all(__classPrivateFieldGet(this, _TransformPool_workers, "f").map(async (worker) => {
            const opened = worker.projects.get(params.projectHandle);
            if (!opened) {
                return;
            }
            try {
                await opened;
                await __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_request).call(this, worker, 'closeProject', params);
            }
            finally {
                worker.projects.delete(params.projectHandle);
            }
        }));
    }
    async transform(params) {
        if (this.workerCount === 1) {
            return __classPrivateFieldGet(this, _TransformPool_mapper, "f").transform(params);
        }
        const project = params.projectHandle
            ? __classPrivateFieldGet(this, _TransformPool_projects, "f").get(params.projectHandle)
            : undefined;
        if (params.projectHandle && !project) {
            throw new Error(`Unknown ${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} project handle: ${params.projectHandle}`);
        }
        let worker = project?.fileWorkers.get(params.fileName);
        if (!worker) {
            worker = project
                ? project.fileWorkers.size < filesBeforeParallelism
                    ? project.primaryWorker
                    : __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_getParallelWorker).call(this, params.fileName)
                : __classPrivateFieldGet(this, _TransformPool_workers, "f")[0];
            if (worker && project) {
                project.fileWorkers.set(params.fileName, worker);
            }
        }
        if (!worker) {
            throw new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} has no available worker`);
        }
        if (project) {
            await __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_ensureProject).call(this, worker, project);
        }
        return __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_request).call(this, worker, 'transform', params);
    }
    async close() {
        __classPrivateFieldGet(this, _TransformPool_projects, "f").clear();
        await Promise.all(__classPrivateFieldGet(this, _TransformPool_workers, "f").map(worker => {
            worker.terminating = true;
            __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_failWorker).call(this, worker, new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} worker pool is shutting down`));
            return worker.thread.terminate();
        }));
    }
}
exports.TransformPool = TransformPool;
_TransformPool_mapper = new WeakMap(), _TransformPool_nextRequestId = new WeakMap(), _TransformPool_projects = new WeakMap(), _TransformPool_workers = new WeakMap(), _TransformPool_workerPath = new WeakMap(), _TransformPool_instances = new WeakSet(), _TransformPool_createWorker = function _TransformPool_createWorker() {
    const thread = new node_worker_threads_1.Worker(__classPrivateFieldGet(this, _TransformPool_workerPath, "f"), {
        stdout: true,
        stderr: true,
    });
    thread.stdout.pipe(process.stderr);
    thread.stderr.pipe(process.stderr);
    const worker = {
        thread,
        pending: new Map(),
        failed: false,
        terminating: false,
        projects: new Map(),
    };
    thread.on('message', (message) => {
        const request = worker.pending.get(message.id);
        if (!request) {
            return;
        }
        worker.pending.delete(message.id);
        if (message.error !== undefined) {
            request.reject(new Error(message.error));
        }
        else {
            request.resolve(message.result);
        }
    });
    thread.on('error', error => __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_failWorker).call(this, worker, error));
    thread.on('exit', code => {
        if (!worker.terminating) {
            __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_failWorker).call(this, worker, new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} worker exited unexpectedly with code ${code}`));
        }
    });
    thread.unref();
    return worker;
}, _TransformPool_getParallelWorker = function _TransformPool_getParallelWorker(fileName) {
    while (__classPrivateFieldGet(this, _TransformPool_workers, "f").length < this.workerCount) {
        __classPrivateFieldGet(this, _TransformPool_workers, "f").push(__classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_createWorker).call(this));
    }
    return __classPrivateFieldGet(this, _TransformPool_workers, "f")[hash(fileName) % __classPrivateFieldGet(this, _TransformPool_workers, "f").length];
}, _TransformPool_ensureProject = function _TransformPool_ensureProject(worker, project) {
    let opened = worker.projects.get(project.params.projectHandle);
    if (!opened) {
        opened = __classPrivateFieldGet(this, _TransformPool_instances, "m", _TransformPool_request).call(this, worker, 'openProject', project.params)
            .then(result => {
            if (project.configIdentity && result.configIdentity !== project.configIdentity) {
                throw new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} workers produced inconsistent project configuration`);
            }
            return result;
        })
            .catch(error => {
            worker.projects.delete(project.params.projectHandle);
            throw error;
        });
        worker.projects.set(project.params.projectHandle, opened);
    }
    return opened;
}, _TransformPool_request = function _TransformPool_request(worker, method, params) {
    var _a;
    if (worker.failed) {
        return Promise.reject(new Error(`${__classPrivateFieldGet(this, _TransformPool_mapper, "f").name} worker is unavailable`));
    }
    const id = __classPrivateFieldSet(this, _TransformPool_nextRequestId, (_a = __classPrivateFieldGet(this, _TransformPool_nextRequestId, "f"), ++_a), "f");
    return new Promise((resolve, reject) => {
        worker.pending.set(id, { resolve, reject });
        try {
            worker.thread.postMessage({ id, method, params });
        }
        catch (error) {
            worker.pending.delete(id);
            reject(error);
        }
    });
}, _TransformPool_failWorker = function _TransformPool_failWorker(worker, error) {
    if (worker.failed) {
        return;
    }
    worker.failed = true;
    for (const request of worker.pending.values()) {
        request.reject(error);
    }
    worker.pending.clear();
};
function readWorkerCount(value = process.env.VUE_CONTENT_MAPPER_WORKERS) {
    if (value === undefined || value === 'auto') {
        return defaultWorkerCount;
    }
    const count = Number(value);
    if (!Number.isSafeInteger(count) || count < 1) {
        throw new Error(`VUE_CONTENT_MAPPER_WORKERS must be "auto" or a positive integer, received ${value}`);
    }
    return count;
}
function hash(value) {
    let result = 2166136261;
    for (let index = 0; index < value.length; index++) {
        result ^= value.charCodeAt(index);
        result = Math.imul(result, 16777619);
    }
    return result >>> 0;
}
