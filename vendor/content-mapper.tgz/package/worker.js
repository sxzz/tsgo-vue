"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const project_1 = require("./project");
const runtime_1 = require("./runtime");
(0, runtime_1.runMapperWorker)(project_1.vueContentMapper);
