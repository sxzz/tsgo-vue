"use strict";
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _IntervalSet_allowExactDuplicates, _IntervalSet_exact, _IntervalSet_root;
Object.defineProperty(exports, "__esModule", { value: true });
exports.toSpanMappings = toSpanMappings;
const protocol_1 = require("./protocol");
const semanticFeatures = protocol_1.SpanMapFeature.Hover
    | protocol_1.SpanMapFeature.SignatureHelp
    | protocol_1.SpanMapFeature.InlayHints
    | protocol_1.SpanMapFeature.SemanticTokens;
const completionFeatures = protocol_1.SpanMapFeature.Completion
    | protocol_1.SpanMapFeature.AutoInsert;
const navigationFeatures = protocol_1.SpanMapFeature.Definition
    | protocol_1.SpanMapFeature.TypeDefinition
    | protocol_1.SpanMapFeature.Implementation
    | protocol_1.SpanMapFeature.References
    | protocol_1.SpanMapFeature.DocumentHighlights
    | protocol_1.SpanMapFeature.Rename
    | protocol_1.SpanMapFeature.CallHierarchy
    | protocol_1.SpanMapFeature.CodeActions
    | protocol_1.SpanMapFeature.LinkedEditing;
const structureFeatures = protocol_1.SpanMapFeature.FoldingRanges
    | protocol_1.SpanMapFeature.SelectionRanges
    | protocol_1.SpanMapFeature.DocumentSymbols
    | protocol_1.SpanMapFeature.CodeLens;
function toSpanMappings(mappings, generatedText, originalText, languageFeatures = true) {
    const candidates = [];
    const entries = [];
    for (const mapping of mappings) {
        for (let index = 0; index < mapping.lengths.length; index++) {
            const generatedStart = mapping.generatedOffsets[index];
            const originalStart = mapping.sourceOffsets[index];
            const length = mapping.lengths[index];
            if (generatedStart === undefined
                || originalStart === undefined
                || length === undefined
                || length < 0
                || generatedStart < 0
                || originalStart < 0) {
                continue;
            }
            entries.push({
                generatedStart,
                generatedLength: length,
                originalStart,
                originalLength: length,
                data: mapping.data,
                token: getCombineToken(mapping.data),
            });
        }
    }
    // Mappings sharing a multi-use __combineToken are chunks of one logical
    // token: camelized identifiers split into segments, or content wrapped in
    // synthesized characters (quotes, escapes, `on` prefixes) bracketed by
    // zero-length boundary markers. Merge each group into a single span so
    // token-wide diagnostics map back to the original range, matching the
    // mapping combiner in the vue-tsc pipeline. A token used only once is
    // decoration (e.g. single-segment camelized names) and stays individual.
    const tokenCounts = new Map();
    for (const entry of entries) {
        if (entry.token !== undefined) {
            tokenCounts.set(entry.token, (tokenCounts.get(entry.token) ?? 0) + 1);
        }
    }
    const combineGroups = new Map();
    for (const entry of entries) {
        if (entry.token !== undefined && tokenCounts.get(entry.token) > 1) {
            const group = combineGroups.get(entry.token);
            if (group) {
                group.push(entry);
            }
            else {
                combineGroups.set(entry.token, [entry]);
            }
        }
    }
    for (const group of combineGroups.values()) {
        group.sort((left, right) => left.generatedStart - right.generatedStart);
        const first = group[0];
        const last = group[group.length - 1];
        entries.push({
            generatedStart: first.generatedStart,
            generatedLength: last.generatedStart + last.generatedLength - first.generatedStart,
            originalStart: first.originalStart,
            originalLength: last.originalStart + last.originalLength - first.originalStart,
            data: first.data,
        });
    }
    const grouped = new Set([...combineGroups.values()].flat());
    for (const entry of entries) {
        if (grouped.has(entry)) {
            continue;
        }
        const { generatedStart, generatedLength, originalStart, originalLength, data } = entry;
        if (generatedStart + generatedLength > generatedText.length
            || originalStart + originalLength > originalText.length) {
            continue;
        }
        const generatedEnd = generatedStart + generatedLength;
        const originalEnd = originalStart + originalLength;
        const verbatim = generatedLength === originalLength
            && generatedText.slice(generatedStart, generatedEnd)
                === originalText.slice(originalStart, originalEnd);
        let features = languageFeatures ? getFeatures(data) : 0;
        if (generatedLength === 0) {
            // Zero-length spans only serve as navigation anchors (e.g. the synthetic
            // default export); drop boundary scaffolding and other zero-length markers.
            if (typeof data !== 'object' || data === null || '__combineToken' in data) {
                continue;
            }
            features &= navigationFeatures;
            if (!features) {
                continue;
            }
        }
        candidates.push({
            generatedStart,
            generatedEnd,
            originalStart,
            originalEnd,
            kind: verbatim ? protocol_1.SpanMapKind.Verbatim : protocol_1.SpanMapKind.Atom,
            features,
        });
    }
    candidates.sort((left, right) => left.kind - right.kind
        || left.generatedStart - right.generatedStart
        || (left.generatedEnd - left.generatedStart) - (right.generatedEnd - right.generatedStart));
    const selected = [];
    const generatedIntervals = new IntervalSet(false);
    const originalIntervals = new IntervalSet(true);
    for (const candidate of candidates) {
        if (!generatedIntervals.canAdd(candidate.generatedStart, candidate.generatedEnd)) {
            continue;
        }
        if (!originalIntervals.canAdd(candidate.originalStart, candidate.originalEnd)) {
            continue;
        }
        generatedIntervals.add(candidate.generatedStart, candidate.generatedEnd);
        originalIntervals.add(candidate.originalStart, candidate.originalEnd);
        selected.push(candidate);
    }
    selected.sort((left, right) => left.generatedStart - right.generatedStart);
    return selected.map(mapping => [
        mapping.generatedStart,
        mapping.generatedEnd - mapping.generatedStart,
        mapping.originalStart,
        mapping.originalEnd - mapping.originalStart,
        mapping.kind,
        mapping.features,
    ]);
}
function getCombineToken(data) {
    if (typeof data === 'object' && data !== null && '__combineToken' in data) {
        const token = data.__combineToken;
        if (typeof token === 'symbol') {
            return token;
        }
    }
    return undefined;
}
function getFeatures(data) {
    if (!isCodeInformation(data)) {
        return 0;
    }
    let features = 0;
    if (data.semantic) {
        features |= semanticFeatures;
        if (typeof data.semantic === 'object'
            && data.semantic.shouldHighlight?.() === false) {
            features &= ~protocol_1.SpanMapFeature.SemanticTokens;
        }
    }
    if (data.completion) {
        features |= completionFeatures;
    }
    if (data.navigation) {
        features |= navigationFeatures;
        if (typeof data.navigation === 'object') {
            if (data.navigation.shouldHighlight?.() === false) {
                features &= ~protocol_1.SpanMapFeature.DocumentHighlights;
            }
            if (data.navigation.shouldRename?.() === false) {
                features &= ~protocol_1.SpanMapFeature.Rename;
            }
        }
    }
    if (data.structure) {
        features |= structureFeatures;
    }
    if (data.format) {
        features |= protocol_1.SpanMapFeature.Formatting;
    }
    return features;
}
function isCodeInformation(value) {
    return typeof value === 'object' && value !== null;
}
function rangesOverlap(startA, endA, startB, endB) {
    return startA < endB && startB < endA;
}
class IntervalSet {
    constructor(allowExactDuplicates) {
        _IntervalSet_allowExactDuplicates.set(this, void 0);
        _IntervalSet_exact.set(this, new Set());
        _IntervalSet_root.set(this, void 0);
        __classPrivateFieldSet(this, _IntervalSet_allowExactDuplicates, allowExactDuplicates, "f");
    }
    canAdd(start, end) {
        if (__classPrivateFieldGet(this, _IntervalSet_allowExactDuplicates, "f") && __classPrivateFieldGet(this, _IntervalSet_exact, "f").has(toKey(start, end))) {
            return true;
        }
        return !hasOverlap(__classPrivateFieldGet(this, _IntervalSet_root, "f"), start, end);
    }
    add(start, end) {
        const key = toKey(start, end);
        if (__classPrivateFieldGet(this, _IntervalSet_allowExactDuplicates, "f") && __classPrivateFieldGet(this, _IntervalSet_exact, "f").has(key)) {
            return;
        }
        __classPrivateFieldGet(this, _IntervalSet_exact, "f").add(key);
        __classPrivateFieldSet(this, _IntervalSet_root, insert(__classPrivateFieldGet(this, _IntervalSet_root, "f"), {
            start,
            end,
            maxEnd: end,
            priority: hashInterval(start, end),
        }), "f");
    }
}
_IntervalSet_allowExactDuplicates = new WeakMap(), _IntervalSet_exact = new WeakMap(), _IntervalSet_root = new WeakMap();
function hasOverlap(node, start, end) {
    if (!node) {
        return false;
    }
    if (node.left && node.left.maxEnd > start && hasOverlap(node.left, start, end)) {
        return true;
    }
    if (rangesOverlap(start, end, node.start, node.end)) {
        return true;
    }
    return node.start < end && hasOverlap(node.right, start, end);
}
function insert(root, node) {
    if (!root) {
        return node;
    }
    if (compareIntervals(node, root) < 0) {
        root.left = insert(root.left, node);
        if (root.left.priority < root.priority) {
            root = rotateRight(root);
        }
    }
    else {
        root.right = insert(root.right, node);
        if (root.right.priority < root.priority) {
            root = rotateLeft(root);
        }
    }
    root.maxEnd = Math.max(root.end, root.left?.maxEnd ?? 0, root.right?.maxEnd ?? 0);
    return root;
}
function rotateLeft(root) {
    const next = root.right;
    root.right = next.left;
    next.left = root;
    root.maxEnd = Math.max(root.end, root.left?.maxEnd ?? 0, root.right?.maxEnd ?? 0);
    next.maxEnd = Math.max(next.end, next.left.maxEnd, next.right?.maxEnd ?? 0);
    return next;
}
function rotateRight(root) {
    const next = root.left;
    root.left = next.right;
    next.right = root;
    root.maxEnd = Math.max(root.end, root.left?.maxEnd ?? 0, root.right?.maxEnd ?? 0);
    next.maxEnd = Math.max(next.end, next.left?.maxEnd ?? 0, next.right.maxEnd);
    return next;
}
function compareIntervals(left, right) {
    return left.start - right.start || left.end - right.end;
}
function hashInterval(start, end) {
    let result = 2166136261;
    result = Math.imul(result ^ start, 16777619);
    result = Math.imul(result ^ end, 16777619);
    return result >>> 0;
}
function toKey(start, end) {
    return `${start}:${end}`;
}
