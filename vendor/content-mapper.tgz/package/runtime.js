"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runMapperServer = runMapperServer;
exports.runMapperWorker = runMapperWorker;
const node_worker_threads_1 = require("node:worker_threads");
const localization_1 = require("./localization");
const workerPool_1 = require("./workerPool");
/** Runs a content mapper process: reads protocol messages from stdin and writes results to stdout. */
function runMapperServer(mapper, options) {
    let input = Buffer.alloc(0);
    const workerPath = readArgument('worker') ?? options.workerPath;
    const typescriptPath = readArgument('typescript');
    if (typescriptPath) {
        process.env.VUE_CONTENT_MAPPER_TYPESCRIPT = typescriptPath;
    }
    const transformPool = new workerPool_1.TransformPool(mapper, undefined, workerPath);
    let unusedExpectErrorMessage = "Unused '@ts-expect-error' directive.";
    console.log =
        console.info =
            console.warn =
                console.debug =
                    (...args) => console.error(...args);
    process.stdin.on('data', chunk => {
        input = Buffer.concat([input, typeof chunk === 'string' ? Buffer.from(chunk) : chunk]);
        readMessages();
    });
    process.stdin.on('error', fail);
    process.stdin.on('end', () => {
        void transformPool.close();
    });
    function readMessages() {
        while (true) {
            const headerEnd = input.indexOf('\r\n\r\n');
            if (headerEnd < 0) {
                return;
            }
            const header = input.subarray(0, headerEnd).toString('ascii');
            const lengthMatch = /^Content-Length:\s*(\d+)$/im.exec(header);
            if (!lengthMatch?.[1]) {
                fail(new Error('Missing Content-Length header'));
                return;
            }
            const contentLength = Number(lengthMatch[1]);
            const messageStart = headerEnd + 4;
            const messageEnd = messageStart + contentLength;
            if (input.length < messageEnd) {
                return;
            }
            const message = JSON.parse(input.subarray(messageStart, messageEnd).toString('utf8'));
            input = input.subarray(messageEnd);
            void handleMessage(message);
        }
    }
    async function handleMessage(message) {
        try {
            const result = message.method === 'initialize'
                ? initialize(message.params)
                : message.method === 'openProject'
                    ? await transformPool.openProject(message.params)
                    : message.method === 'closeProject'
                        ? await transformPool.closeProject(message.params)
                        : message.method === 'transform'
                            ? localizeDiagnosticDirectives(await transformPool.transform(message.params))
                            : undefined;
            if (result === undefined && message.method !== 'closeProject') {
                writeMessage({
                    jsonrpc: '2.0',
                    id: message.id,
                    error: { code: -32601, message: `Unknown method ${message.method}` },
                });
                return;
            }
            writeMessage({ jsonrpc: '2.0', id: message.id, result: result ?? null });
        }
        catch (error) {
            writeMessage({
                jsonrpc: '2.0',
                id: message.id,
                error: {
                    code: -32603,
                    message: error instanceof Error ? error.message : String(error),
                },
            });
        }
    }
    function initialize(params) {
        unusedExpectErrorMessage = (0, localization_1.getUnusedExpectErrorMessage)(params.locale, typescriptPath);
        return {
            positionEncoding: selectPositionEncoding(params.positionEncodings),
            diagnosticSource: mapper.diagnosticSource,
        };
    }
    function selectPositionEncoding(encodings) {
        if (encodings.includes('utf-16')) {
            return 'utf-16';
        }
        throw new Error(`${mapper.name} requires UTF-16 position encoding`);
    }
    function localizeDiagnosticDirectives(result) {
        for (const diagnostic of result.diagnosticDirectives?.unusedExpectDirectiveDiagnostics ?? []) {
            diagnostic.messageText = unusedExpectErrorMessage;
        }
        return result;
    }
    function writeMessage(message) {
        const body = Buffer.from(JSON.stringify(message));
        process.stdout.write(`Content-Length: ${body.length}\r\n\r\n`);
        process.stdout.write(body);
    }
    function fail(error) {
        console.error(error);
        process.exitCode = 1;
    }
}
/** Runs a content mapper worker thread, which owns the project state of the worker pool. */
function runMapperWorker(mapper) {
    if (!node_worker_threads_1.parentPort) {
        throw new Error(`${mapper.name} worker requires a parent port`);
    }
    node_worker_threads_1.parentPort.on('message', ({ id, method, params }) => {
        try {
            const result = method === 'openProject'
                ? mapper.openProject(params)
                : method === 'closeProject'
                    ? mapper.closeProject(params.projectHandle)
                    : mapper.transform(params);
            node_worker_threads_1.parentPort.postMessage({ id, result });
        }
        catch (error) {
            node_worker_threads_1.parentPort.postMessage({
                id,
                error: error instanceof Error ? error.message : String(error),
            });
        }
    });
}
function readArgument(name) {
    const prefix = `--${name}=`;
    const argument = process.argv.find(argument => argument.startsWith(prefix));
    return argument?.slice(prefix.length);
}
