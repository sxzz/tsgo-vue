"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadTypeScript = loadTypeScript;
let loaded;
function loadTypeScript() {
    return loaded ??= require(process.env.VUE_CONTENT_MAPPER_TYPESCRIPT ?? 'typescript');
}
