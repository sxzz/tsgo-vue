"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createContentMapper = createContentMapper;
const vue = __importStar(require("@vue/language-core"));
const node_crypto_1 = require("node:crypto");
const path = __importStar(require("node:path"));
const diagnosticDirectives_1 = require("./diagnosticDirectives");
const spanMappings_1 = require("./spanMappings");
const typescript_1 = require("./typescript");
const ts = (0, typescript_1.loadTypeScript)();
/**
 * Creates the project configuration and transform pipeline shared by every Vue content mapper.
 * Files reach a mapper because the host registered its extensions, so the front-end only decides
 * how a file is understood, not which files arrive.
 */
function createContentMapper(frontend) {
    const projects = new Map();
    const defaultLanguageId = frontend.defaultLanguageId ?? 'vue';
    function openProject(params) {
        const state = {
            params,
            configurations: new Map(),
        };
        projects.set(params.projectHandle, state);
        // Inferred projects have no tsconfig, but resolving `target: 'auto'` and the mapper entry's
        // `plugins` still reads dynamic inputs, so the configuration is always created through the
        // watching host.
        const watchedFiles = new Set();
        createConfiguration(state, params.configFileName, watchedFiles);
        return {
            configIdentity: createIdentity(params, watchedFiles),
            watchedFiles: [...watchedFiles].sort(),
            optionDiagnostics: frontend.toOptionDiagnostics?.(params.options),
        };
    }
    function closeProject(projectHandle) {
        const state = projects.get(projectHandle);
        if (state) {
            for (const configuration of state.configurations.values()) {
                for (const [fileName, virtualCode] of configuration.virtualCodes) {
                    configuration.plugin.disposeVirtualCode?.(fileName, virtualCode);
                }
            }
        }
        projects.delete(projectHandle);
    }
    function transform(params) {
        const state = params.projectHandle
            ? projects.get(params.projectHandle)
            : undefined;
        if (params.projectHandle && !state) {
            throw new Error(`Unknown ${frontend.name} project handle: ${params.projectHandle}`);
        }
        const configuration = state
            ? getConfiguration(state)
            : createStandaloneConfiguration(params);
        const snapshot = ts.ScriptSnapshot.fromString(params.content);
        const languageId = configuration.plugin.getLanguageId(params.fileName) ?? defaultLanguageId;
        const root = configuration.plugin.createVirtualCode?.(params.fileName, languageId, snapshot, { getAssociatedScript: () => undefined });
        if (root) {
            configuration.virtualCodes.set(params.fileName, root);
        }
        const serviceScript = root && configuration.plugin.typescript?.getServiceScript(root);
        if (!serviceScript) {
            return {
                text: 'export {};\n',
                extension: '.ts',
                mappings: [],
            };
        }
        const text = serviceScript.code.snapshot.getText(0, serviceScript.code.snapshot.getLength());
        const extension = getVirtualExtension(serviceScript.extension);
        const mappings = (0, spanMappings_1.toSpanMappings)(serviceScript.code.mappings, text, params.content, configuration.languageFeatures);
        const diagnosticDirectives = (0, diagnosticDirectives_1.toDiagnosticDirectives)(serviceScript.code.mappings);
        return {
            text,
            extension,
            diagnosticDirectives: {
                unusedExpectDirectiveDiagnostics: [{
                        code: 2578,
                        messageText: "Unused '@vue-expect-error' directive.",
                    }],
                directives: (0, diagnosticDirectives_1.withSynthesizedDiagnosticIgnores)(text.length, mappings, diagnosticDirectives),
            },
            mappings,
        };
    }
    function getVirtualExtension(extension) {
        switch (extension) {
            case '.js':
                return '.js';
            case '.jsx':
                return '.jsx';
            case '.ts':
                return '.ts';
            case '.tsx':
                return '.tsx';
            case '.mjs':
            case '.cjs':
            case '.mts':
            case '.cts':
            case '.json':
                return extension;
            default:
                throw new Error(`Unsupported Vue service script extension: ${extension}`);
        }
    }
    function getConfiguration(state) {
        const configFileName = state.params.configFileName;
        let configuration = state.configurations.get(configFileName);
        if (!configuration) {
            configuration = createConfiguration(state, configFileName);
        }
        return configuration;
    }
    function createConfiguration(state, configFileName, watchedFiles) {
        const host = watchedFiles
            ? {
                ...ts.sys,
                readFile(fileName) {
                    const content = ts.sys.readFile(fileName);
                    if (content !== undefined && path.isAbsolute(fileName)) {
                        watchedFiles.add(path.normalize(fileName));
                    }
                    return content;
                },
            }
            : ts.sys;
        const rootDir = configFileName
            ? path.dirname(configFileName)
            : process.cwd();
        if (watchedFiles && configFileName) {
            watchedFiles.add(path.normalize(configFileName));
        }
        const { languageFeatures, ...mapperOptions } = state.params.options ?? {};
        const watchedBefore = watchedFiles ? new Set(watchedFiles) : undefined;
        const parsed = configFileName
            ? vue.createParsedCommandLine(ts, host, normalizePath(configFileName))
            : undefined;
        // `createParsedCommandLine` is the only reader of the tsconfig `extends` chain, so the files it
        // added are exactly the configs that may declare legacy Vue options.
        const configFileNames = configFileName
            ? [
                normalizePath(configFileName),
                ...(watchedFiles && watchedBefore
                    ? [...watchedFiles].filter(fileName => !watchedBefore.has(fileName))
                    : []),
            ]
            : [];
        // v4 moves the Vue compiler options from the tsconfig's `vueCompilerOptions` field to the mapper
        // entry's `options`; apply the entry options on top of any options a tsconfig still carries.
        const baseVueOptions = parsed?.vueOptions ?? vue.getDefaultCompilerOptions();
        const resolver = new vue.CompilerOptionsResolver(ts, host.readFile);
        resolver.addConfig(mapperOptions, normalizePath(rootDir));
        const vueOptions = resolver.build({
            ...baseVueOptions,
            target: resolver.target ?? baseVueOptions.target,
            typesRoot: resolver.typesRoot ?? baseVueOptions.typesRoot,
        });
        vueOptions.plugins = [
            ...new Set([
                ...frontend.plugins?.({ rootDir: normalizePath(rootDir) }) ?? [],
                ...baseVueOptions.plugins,
                ...resolver.plugins,
            ]),
        ];
        const compilerOptions = normalizeCompilerOptions(state.params.compilerOptions);
        const configuration = {
            plugin: vue.createVueLanguagePlugin(ts, { ...parsed?.options, ...compilerOptions }, vueOptions, fileName => fileName),
            languageFeatures: languageFeatures !== false,
            virtualCodes: new Map(),
        };
        if (watchedFiles) {
            addPluginWatchFiles(watchedFiles, mapperOptions.plugins, rootDir);
            addConfigPluginWatchFiles(watchedFiles, configFileNames);
        }
        state.configurations.set(configFileName, configuration);
        return configuration;
    }
    function createStandaloneConfiguration(params) {
        const configFileName = ts.findConfigFile(path.dirname(params.fileName), ts.sys.fileExists);
        const parsed = configFileName
            ? vue.createParsedCommandLine(ts, ts.sys, normalizePath(configFileName))
            : vue.createParsedCommandLineByJson(ts, ts.sys, normalizePath(path.dirname(params.fileName)), {});
        const vueOptions = {
            ...parsed.vueOptions,
            plugins: [
                ...new Set([
                    ...frontend.plugins?.({ rootDir: normalizePath(path.dirname(params.fileName)) }) ?? [],
                    ...parsed.vueOptions.plugins,
                ]),
            ],
        };
        return {
            plugin: vue.createVueLanguagePlugin(ts, parsed.options, vueOptions, fileName => fileName),
            languageFeatures: true,
            virtualCodes: new Map(),
        };
    }
    return {
        name: frontend.name,
        diagnosticSource: frontend.diagnosticSource ?? 'vue',
        openProject,
        closeProject,
        transform,
    };
}
function normalizeCompilerOptions(options) {
    // `options` already arrives in the numeric-enum wire format that
    // `ts.CompilerOptions` expects; `convertCompilerOptionsFromJson` expects
    // string enums and silently drops numeric `lib`/`target`/`module`/`jsx`.
    return options;
}
function createIdentity(params, watchedFiles) {
    const hash = (0, node_crypto_1.createHash)('sha256');
    hash.update(JSON.stringify(params.options ?? null));
    hash.update(JSON.stringify(params.compilerOptions));
    for (const fileName of [...watchedFiles].sort()) {
        hash.update(fileName);
        hash.update(ts.sys.readFile(fileName) ?? '');
    }
    return hash.digest('hex');
}
function addPluginWatchFiles(watchedFiles, plugins, rootDir) {
    if (!Array.isArray(plugins)) {
        return;
    }
    for (const plugin of plugins) {
        const name = typeof plugin === 'string' ? plugin : plugin?.name;
        if (typeof name !== 'string') {
            continue;
        }
        try {
            watchedFiles.add(require.resolve(name, { paths: [rootDir] }));
        }
        catch { }
    }
}
/**
 * A tsconfig may still carry `vueCompilerOptions.plugins`; `createParsedCommandLine` loads those
 * plugins, so their entry files participate in transforms and must be watched as well.
 */
function addConfigPluginWatchFiles(watchedFiles, configFileNames) {
    for (const configFileName of configFileNames) {
        const content = ts.sys.readFile(configFileName);
        if (content === undefined) {
            continue;
        }
        const plugins = ts.parseConfigFileTextToJson(configFileName, content).config?.vueCompilerOptions?.plugins;
        if (plugins !== undefined) {
            addPluginWatchFiles(watchedFiles, plugins, path.dirname(configFileName));
        }
    }
}
function normalizePath(fileName) {
    return fileName.replace(/\\/g, '/');
}
